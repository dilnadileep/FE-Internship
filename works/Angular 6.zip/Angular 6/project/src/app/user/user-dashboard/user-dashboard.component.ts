// src/app/user/user.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-user-dashboard',
  template: `<h2>User Dashboard</h2>`,
})
export class UserDashboardComponent {}
