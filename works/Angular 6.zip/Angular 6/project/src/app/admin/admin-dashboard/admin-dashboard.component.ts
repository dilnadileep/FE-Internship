// src/app/admin/admin.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard',
  template: `<h2>Admin Dashboard</h2>`,
})
export class AdminDashboardComponent {}
