import { Component } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent {

  // Method to display an alert when the button is clicked
  onSaveChanges(): void {
    alert('Your details have been updated successfully!');
  }

}
