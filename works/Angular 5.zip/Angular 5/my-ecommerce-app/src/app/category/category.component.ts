import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent {
  categories = [
    { id: 1, name: 'Electronics', description: 'Find the latest gadgets and tech.' },
    { id: 2, name: 'Fashion', description: 'Explore our trendy clothing collection.' },
    { id: 3, name: 'Home', description: 'Upgrade your living space with stylish furniture.' }
  ];


  // Injecting the Router service into the constructor to navigate between routes
  constructor(private router: Router) {}

    // Method to navigate to the product page for the selected category
  navigateToCategory(id: number, name: string) {

    this.router.navigate([`/product/${id}`], { queryParams: { category: name } });      // Using the Router service to navigate to the product page with category ID
                                                                                        // Also passing the category name as a query parameter
  }
  
}
