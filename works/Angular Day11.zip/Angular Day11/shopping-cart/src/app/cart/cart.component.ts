import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../services/cart.service';
import { Observable, Subscription, Subject } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class CartComponent implements OnInit, OnDestroy {
  cartItems$!: Observable<any[]>; // Observable for cart items
  total$!: Observable<number>; // Observable for total price

  editEnabled = true; 
  deleteEnabled = true; 

  private cartUpdateSubscription!: Subscription; // Subscription to cart updates
  editEnabledSubject = new Subject<boolean>(); // Subject to notify edit toggle changes
  deleteEnabledSubject = new Subject<boolean>(); // Subject to notify delete toggle changes

  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.cartItems$ = this.cartService.cartItems$; // Get cart items as observable
    this.total$ = this.cartService.getTotalPrice(); // Get total price as observable

    // Subscribe to cart updates
    this.cartUpdateSubscription = this.cartService.onCartUpdated().subscribe({   
      next: () => console.log('Cart updated!'),  // Observer to handle next, error, and complete explicitly.
      error: (err) => console.error('Error in cart update:', err), 
      complete: () => console.log('Cart update stream completed'), 
    });
  }

  increaseQuantity(item: any) {
    if (this.editEnabled) {
      this.cartService.increaseQuantity(item); // Increase item quantity
    }
  }

  decreaseQuantity(item: any) {
    if (this.editEnabled && item.quantity > 1) {
      this.cartService.decreaseQuantity(item); // Decrease item quantity
    }
  }

  removeItem(item: any) {
    if (this.deleteEnabled) {
      this.cartService.removeItem(item); // Remove item from cart
    }
  }

  toggleEditFeature() {
    this.editEnabled = !this.editEnabled; // Toggle edit feature
    this.editEnabledSubject.next(this.editEnabled); // Notify subscribers
  }

  toggleDeleteFeature() {
    this.deleteEnabled = !this.deleteEnabled; // Toggle delete feature
    this.deleteEnabledSubject.next(this.deleteEnabled); // Notify subscribers
  }

  ngOnDestroy() {
    if (this.cartUpdateSubscription) {
      this.cartUpdateSubscription.unsubscribe(); // Unsubscribe to prevent memory leaks
    }
  }
}
