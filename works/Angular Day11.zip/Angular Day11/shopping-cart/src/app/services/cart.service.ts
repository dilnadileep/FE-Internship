import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, asyncScheduler } from 'rxjs';
import { map, observeOn } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartItems = new BehaviorSubject<any[]>([]); // Holds the current state of the cart
  cartItems$ = this.cartItems.asObservable(); // Expose cart items as an observable for subscription
  private cartUpdated = new Subject<void>(); // Subject to notify when the cart is updated

  addToCart(product: any) {
    const items = this.cartItems.getValue(); // Get the current cart items
    const existingItem = items.find((item) => item.id === product.id);

    if (existingItem) {
      existingItem.quantity++; // Increment quantity if item already exists
    } else {
      items.push({ ...product, quantity: 1 }); // Add new item with quantity 1
    }

    this.cartItems.next(items); // Update the cart state
    this.cartUpdated.next(); // Notify cart update
  }

  increaseQuantity(item: any) {
    const items = this.cartItems.getValue(); // Get the current cart items
    const existingItem = items.find((i) => i.id === item.id);

    if (existingItem) {
      existingItem.quantity++; 
      this.cartItems.next(items); 
      this.cartUpdated.next(); 
    }
  }

  decreaseQuantity(item: any) {
    const items = this.cartItems.getValue(); // Get the current cart items
    const existingItem = items.find((i) => i.id === item.id);

    if (existingItem && existingItem.quantity > 1) {
      existingItem.quantity--; 
      this.cartItems.next(items); 
      this.cartUpdated.next(); 
    }
  }

     // Remove item from cart with a Promise
    removeItem(item: any): Promise<void> {
      return new Promise((resolve, reject) => {
        try {
          const items = this.cartItems.getValue().filter((i) => i.id !== item.id); // Remove the item
          this.cartItems.next(items); 
          this.cartUpdated.next(); 
          resolve(); // Resolve the promise after successful operation
        } catch (error) {
          reject(error); // Reject the promise if any error occurs
        }
      });
    }

  getTotalPrice(): Observable<number> {
    return this.cartItems$.pipe(
      map((items) =>
        items.reduce((acc, item) => acc + item.price * item.quantity, 0) 
      ),
      observeOn(asyncScheduler) // Perform the calculation asynchronously
    );
  }

  onCartUpdated(): Observable<void> {
    return this.cartUpdated.asObservable(); // Expose the cart update subject as an observable
  }
}
