import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
  standalone: true,
  imports: [CommonModule, HttpClientModule],
})
export class ProductListComponent implements OnInit {
  products: any[] = []; // Array to store fetched products
  addEnabled = true; 

  constructor(private http: HttpClient, private cartService: CartService) {}

  ngOnInit() {
    // Observer to handle HTTP responses
    const productsObserver = {
      next: (data: any[]) => {
        this.products = data; // Update products array on success
      },
      error: (err: any) => console.error('Error fetching products:', err), // Log errors
      complete: () => console.log('Product fetch completed'), // Log completion
    };

    // Fetch products from API and subscribe to the response
    this.http.get<any[]>('https://fakestoreapi.com/products').subscribe(productsObserver);
  }

  addToCart(product: any) {
    if (this.addEnabled) {
      this.cartService.addToCart(product); // Add product to cart if addEnabled is true
    }
  }

  toggleAddFeature() {
    this.addEnabled = !this.addEnabled; 
  }
}
