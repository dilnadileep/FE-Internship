import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
})
export class RegistrationComponent implements OnInit {
  reactiveForm: FormGroup;
  submitted = false;
  user: any;

  constructor(private fb: FormBuilder, private userService: UserService) {   // Inject the UserService
    // Initialize the form with form controls and validators
    this.reactiveForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
    });
  }

  ngOnInit(): void {}
  get passwordsMatch(): boolean {
    const password = this.reactiveForm.get('password')?.value;
    const confirmPassword = this.reactiveForm.get('confirmPassword')?.value;
    return password === confirmPassword;
  }
  // Submit method for the reactive form
  onSubmitReactive() {
    this.submitted = true;
    if (this.reactiveForm.invalid) {
      return;
    }
    this.user = this.reactiveForm.value;
    this.userService.addUser(this.user); // Store user data in the service array
  }

  // Getter to retrieve all users from the service
  get users() {
    return this.userService.getUsers();
  }

  // Getter for easy access to form controls
  get f() {
    return this.reactiveForm.controls;
  }
}
