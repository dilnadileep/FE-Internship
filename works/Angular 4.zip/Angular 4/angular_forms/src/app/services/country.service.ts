import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CountryService {
  constructor() {}

  // Method to search for countries based on a query string
  searchCountries(query: string, data: any[]) {
    if (query === '') {
      // If the search query is empty, return the entire dataset
      return data;
    } else {
      // Filter the dataset to return only countries whose name includes the search query (case-insensitive)
      return data.filter((country: any) =>
        country.name.toLowerCase().includes(query.toLowerCase())
      );
    }
  }

  // Method to paginate the data
  paginate(data: any[], pageSize: number, currentPage: number): any[] {
    // Calculate the starting index for the current page based on page size and page number
    const startIndex = (currentPage - 1) * pageSize;

    // Return a slice of the data array that represents the current page's items
    return data.slice(startIndex, startIndex + pageSize);
  }

  // Method to calculate the total number of pages based on data size and page size
  getPageCount(data: any[], pageSize: number): number {
    // Divide the data length by the page size and round up to get the total number of pages
    return Math.ceil(data.length / pageSize);
  }
}
