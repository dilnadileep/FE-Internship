import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private users: any[] = []; // Array to store user details

  // Method to add a user to the array
  addUser(user: any) {
    this.users.push(user);
  }

  // Method to retrieve the list of users
  getUsers() {
    return this.users;
  }
}
