import { Component } from '@angular/core';
import { CountryService } from '../services/country.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-country-list',
  standalone: true,
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.css'],
  imports: [FormsModule, CommonModule],
})
export class CountryListComponent {
  // Array of country objects, each with a name, code, and capital
  private countries = [
    { name: 'United States', code: 'US', capital: 'Washington D.C.' },
    { name: 'Canada', code: 'CA', capital: 'Ottawa' },
    { name: 'Mexico', code: 'MX', capital: 'Mexico City' },
    { name: 'United Kingdom', code: 'GB', capital: 'London' },
    { name: 'France', code: 'FR', capital: 'Paris' },
    { name: 'Germany', code: 'DE', capital: 'Berlin' },
    { name: 'Italy', code: 'IT', capital: 'Rome' },
    { name: 'Spain', code: 'ES', capital: 'Madrid' },
    { name: 'Australia', code: 'AU', capital: 'Canberra' },
    { name: 'Brazil', code: 'BR', capital: 'Brasília' },
    { name: 'Argentina', code: 'AR', capital: 'Buenos Aires' },
    { name: 'China', code: 'CN', capital: 'Beijing' },
    { name: 'India', code: 'IN', capital: 'New Delhi' },
    { name: 'Japan', code: 'JP', capital: 'Tokyo' },
    { name: 'South Korea', code: 'KR', capital: 'Seoul' },
    { name: 'Russia', code: 'RU', capital: 'Moscow' },
    { name: 'South Africa', code: 'ZA', capital: 'Pretoria' },
    { name: 'Egypt', code: 'EG', capital: 'Cairo' },
    { name: 'Saudi Arabia', code: 'SA', capital: 'Riyadh' },
    { name: 'Turkey', code: 'TR', capital: 'Ankara' },
    { name: 'Netherlands', code: 'NL', capital: 'Amsterdam' },
    { name: 'Nigeria', code: 'NG', capital: 'Abuja' },
    { name: 'Philippines', code: 'PH', capital: 'Manila' },
    { name: 'Thailand', code: 'TH', capital: 'Bangkok' },
    { name: 'Sweden', code: 'SE', capital: 'Stockholm' },
    { name: 'Norway', code: 'NO', capital: 'Oslo' },
    { name: 'New Zealand', code: 'NZ', capital: 'Wellington' },
    { name: 'Finland', code: 'FI', capital: 'Helsinki' },
    { name: 'Greece', code: 'GR', capital: 'Athens' },
  ];

  // Array to hold the filtered list of countries based on search and pagination
  filtercountries: any[] = [];

  // User's search input for filtering the country list
  searchQuery: string = '';

  currentPage: number = 1;   
  pageSize: number = 5;      
  totalPages: number = 0;    

  // Injecting the CountryService to handle search and pagination logic
  constructor(private countryService: CountryService) {
    this.applyFilters(); // Initialize the filtered list with the default (all countries)
  }

  // Applies the search and pagination filters to the countries list
  applyFilters() {
    // Step 1: Filter countries based on the search query
    const filteredData = this.countryService.searchCountries(
      this.searchQuery,
      this.countries
    );

    // Step 2: Calculate the total number of pages based on the filtered data
    this.totalPages = this.countryService.getPageCount(filteredData, this.pageSize);

    // Step 3: Get the data for the current page from the filtered list
    this.filtercountries = this.countryService.paginate(
      filteredData,
      this.pageSize,
      this.currentPage
    );
  }

  // Triggered when the user types a new search query
  searchCountries() {
    this.currentPage = 1; // Reset to the first page after a new search
    this.applyFilters();  // Apply the search and pagination filters
  }

  // Navigates to a specified page if it falls within the valid range
  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {  // Ensure page number is valid
      this.currentPage = page;  // Update the current page
      this.applyFilters();      // Reapply filters to get data for the new page
    }
  }
}
