import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service'; 
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-registration2',
  standalone: true,
  templateUrl: './registration2.component.html',
  imports: [FormsModule, CommonModule], 
  styleUrls: ['./registration2.component.css'],
})
export class Registration2Component {
  submitted = false;
  user = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  };
  users: any[] = []; // Array to hold the user data

  constructor(private userService: UserService) {} // Inject the UserService

  onSubmitTemplate(form: NgForm) {
    this.submitted = true;
    if (form.invalid) {
      return;
    }
    this.userService.addUser(form.value); // Add user data to the service
    this.users = this.userService.getUsers(); // Retrieve the updated users array
    form.reset(); // Optionally reset the form after submission
  }
}
