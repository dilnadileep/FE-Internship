import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'truncate',
  standalone: true,
  pure :true
})
export class TruncatePipe implements PipeTransform {

  transform(value: string, maxLength: number = 20, ellipsis: string = '...'): string {
    if (value.length > maxLength) {
      return value.slice(0, maxLength) + ellipsis; // Transforms the input value
    }
    return value;
  }

}
