import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TruncatePipe } from './truncate.pipe';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, TruncatePipe,HttpClientModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  title = 'Abstract concepts and empirical evidence challenge understanding.';
  longText = 'Psychology explores how humans think, feel, and behave. It helps us understand emotions, relationships, and personal growth, offering tools to improve mental well-being and navigate life challenges.';
  currentDate = new Date();
  numberValue = 123456.789;
  price = 1234.56;

  //asyncpipe
  data$: Observable<any>;

  constructor(private http: HttpClient) {
        // The API call will be assigned to the Observable, and the data will be handled by the AsyncPipe in the template.
    this.data$ = this.http.get('https://jsonplaceholder.typicode.com/posts/1');  // Make an HTTP GET request to fetch data
     // using async pipe data can directly bind it in the template
  }
  
}
