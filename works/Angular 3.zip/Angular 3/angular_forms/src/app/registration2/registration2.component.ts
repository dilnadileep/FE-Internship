import { Component } from '@angular/core'; // Import Angular core module
import { NgForm } from '@angular/forms'; // Import NgForm for template-driven forms
import { FormsModule } from '@angular/forms'; // Import FormsModule for form directives
import { CommonModule } from '@angular/common'; // Import CommonModule for Angular common directives

@Component({
  selector: 'app-registration2', 
  standalone: true,
  templateUrl: './registration2.component.html', 
  imports: [FormsModule, CommonModule],
  styleUrls: ['./registration2.component.css'], 
})
export class Registration2Component {
  submitted = false; // Flag to track if the form has been submitted
  user = { // Object to hold user information
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  };

  // Method to handle form submission
  onSubmitTemplate(form: NgForm) { 
    this.submitted = true; // Set the submitted flag to true
    if (form.invalid) { // Check if the form is invalid
      return; // Exit if the form is invalid
    }
    this.user = form.value; // Assign the form values to the user object upon successful submission
  }
}
