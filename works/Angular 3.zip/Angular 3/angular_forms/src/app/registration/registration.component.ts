import { Component, OnInit } from '@angular/core'; 
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; 
import { CommonModule } from '@angular/common'; 
import { ReactiveFormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-registration', 
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule], 
  templateUrl: './registration.component.html', 
  styleUrls: ['./registration.component.css'], 
})
export class RegistrationComponent implements OnInit { 
  reactiveForm!: FormGroup; // Declare a reactive form group
  submitted = false; // Flag to track if the form has been submitted
  user = { // Object to hold user information
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  };

  constructor(private fb: FormBuilder) {} // Inject FormBuilder service into the constructor

  ngOnInit(): void { // Lifecycle hook that is called after the component is initialized
    // Initialize the reactive form with form controls and their validators
    this.reactiveForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(10)]], 
      email: ['', [Validators.required, Validators.email]], 
      password: [
        '', // Password control with required and pattern validators
        [
          Validators.required,
          Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+'), // Password must contain at least one uppercase letter, one lowercase letter, and one digit
        ],
      ],
      confirmPassword: ['', Validators.required], // Confirm Password control with required validator
    });
  }

  get f() { // Getter to access form controls easily
    return this.reactiveForm.controls; // Return the controls of the reactive form
  }

  onSubmitReactive() { // Method to handle form submission
    this.submitted = true; // Set the submitted flag to true
    if (this.reactiveForm.invalid) { // Check if the form is invalid
      return; // Exit if the form is invalid
    }
    this.user = this.reactiveForm.value; // Assign the form values to the user object upon successful submission
  }

  get passwordsMatch() { // Getter to check if the password and confirm password match
    return this.f['password'].value === this.f['confirmPassword'].value; 
  }
}
