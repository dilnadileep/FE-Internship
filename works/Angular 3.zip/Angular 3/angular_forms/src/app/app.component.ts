import { Component } from '@angular/core';
import { RegistrationComponent } from './registration/registration.component'; 

import { Registration2Component } from './registration2/registration2.component'; 

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [Registration2Component,RegistrationComponent], 
})
export class AppComponent {
}
