import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, switchMap, tap } from 'rxjs/operators'; // Import the RxJS operators
import { of } from 'rxjs'; // Import 'of' to return an observable from a static value

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/posts'; 

  constructor(private http: HttpClient) {} 

  // Method to fetch data from the API
  getData() {
    return this.http.get(this.apiUrl).pipe( // Initiating HTTP GET request to the API
      tap((data) => {
        // 'tap' is used for side effects, it logs data before any transformation
        console.log('Data received:', data); 
      }),
      switchMap((data) => {
        // 'switchMap' is used to switch to a new observable, in this case, to simulate an error
        if (data) {
          throw new Error('Simulated API error');
        }
        return of(data); 
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error occurred while fetching data:', error.message);
        return of({ error: true, message: 'An error occurred while fetching data.' });
      }),
      tap((result) => {
        // 'tap' is used again to log the final result (either the data or the error message)
        console.log('Final result or error handled:', result); 
      })
    );
  }
}
