import { Component, OnInit } from '@angular/core';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  data: any;
  errorMessage: string | null = null;
  loading: boolean = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.getData();
  }

  getData(): void {
    this.loading = true;
    this.errorMessage = '';
    this.apiService.getData().subscribe(
      (response) => {
        // Success callback
        if (response && response.error) {
          this.errorMessage = response.message;
        } else {
          this.data = response;
        }
        this.loading = false;
      },
      (error) => {
        // Error callback
        this.errorMessage = 'An unexpected error occurred: ' + error.message;
        this.loading = false;
      }
    );
  }
}
