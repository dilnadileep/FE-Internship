import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Get_postService } from '../get-post.service';  // Import the ApiService

@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
})
export class PostdetailsComponent {
  postForm: FormGroup;
  postedData: any;

  constructor(private fb: FormBuilder, private apiService: Get_postService) { // Inject ApiService
    this.postForm = this.fb.group({
      title: [''],
      body: [''],
      userId: ['']
    });
  }

  onSubmit(): void {
    const formData = this.postForm.value;
    this.apiService.postData(formData).subscribe(response => {
      this.postedData = response; // Handle the response
    });
  }
}
