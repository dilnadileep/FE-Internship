import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Get_postService {
  private baseUrl = 'https://jsonplaceholder.typicode.com';

  constructor(private http: HttpClient) {}

  // Get photo details by ID
  getPhotoById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/photos/${id}`);
  }

  // Post data
  postData(formData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/posts`, formData);
  }
}
