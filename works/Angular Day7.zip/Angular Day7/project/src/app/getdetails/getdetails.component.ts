import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Get_postService } from '../get-post.service';  // Import the ApiService

@Component({
  selector: 'app-getdetails',
  templateUrl: './getdetails.component.html',
})
export class GetdetailsComponent implements OnInit {
  getForm: FormGroup;
  retrievedPhoto: any; // Stores the fetched photo data

  constructor(private fb: FormBuilder, private apiService: Get_postService) { // Inject ApiService
    this.getForm = this.fb.group({
      id: ['']
    });
  }

  ngOnInit(): void {}

  onGetData(): void {
    const id = this.getForm.get('id')?.value;
    this.apiService.getPhotoById(id).subscribe(
      (data) => {
        this.retrievedPhoto = data; // Assign data to retrievedPhoto
      },
      (error) => {
        console.error('Error fetching photo:', error);
      }
    );
  }
}
