import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'nghttp';
  postForm!: FormGroup; // Add `!` to assure TypeScript this will be assigned later
  postData: any;

  constructor(private http: HttpClient, private fb: FormBuilder) {}

  ngOnInit(): void {
    // Initialize the form with FormBuilder
    this.postForm = this.fb.group({
      title: [''],
      body: [''],
      userId: [1]  // default user ID
    });
  }


}