import { Component, OnInit } from '@angular/core';
import { LoaderService } from '../../services/loader.service';  

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html', 
  styleUrls: ['./loading.component.scss']  
})
export class LoadingComponent implements OnInit {
  loading = false;  

  // Inject the LoaderService to subscribe to the loading state changes
  constructor(private loaderService: LoaderService) {}

  ngOnInit() {
    // Subscribe to the loading$ observable from the LoaderService to track the loading state
    this.loaderService.loading$.subscribe((loading) => {
      this.loading = loading;  // Update the local 'loading' variable based on the emitted value
    });
  }
}
