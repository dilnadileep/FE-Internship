import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LoaderService } from './services/loader.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  username = '';
  password = '';
  isLoggedIn = false;

  constructor(private http: HttpClient, private loaderService: LoaderService) {}

  onLogin() {
    const loginData = { username: this.username, password: this.password };
    
    // Simulate login API request
    this.loaderService.show();  // Show loader
    this.http.post<any>('https://jsonplaceholder.typicode.com/posts', loginData).subscribe(
      (response) => {
        console.log('Login success', response);
        localStorage.setItem('authToken', 'sample-token');  // Store token
        this.isLoggedIn = true;
        this.loaderService.hide();  // Hide loader
      },
      (error) => {
        console.error('Login error', error);
        this.loaderService.hide();  // Hide loader
      }
    );
  }

  onLogout() {
    localStorage.removeItem('authToken');
    this.isLoggedIn = false;
  }
}
