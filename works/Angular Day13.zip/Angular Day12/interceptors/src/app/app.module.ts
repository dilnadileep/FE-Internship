import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'; 

import { FormsModule } from '@angular/forms';
import { LoadingComponent } from './components/loading/loading.component';  

@NgModule({
  declarations: [
    AppComponent,
    LoadingComponent  
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatInputModule,             
    MatFormFieldModule,        
    MatButtonModule,             
    MatProgressSpinnerModule,    
    FormsModule                  
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
