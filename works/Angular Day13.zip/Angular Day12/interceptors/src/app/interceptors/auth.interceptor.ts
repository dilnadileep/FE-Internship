import { HttpInterceptorFn, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

// Define the interceptor function to add the Authorization header
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  
  const token = localStorage.getItem('authToken');
  console.log('Token:', token);  // Check if token is being fetched correctly
  if (token) {
    const clonedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(clonedReq);
  }
  return next(req);
};

