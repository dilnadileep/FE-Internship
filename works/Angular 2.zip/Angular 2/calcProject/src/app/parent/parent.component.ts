import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplayComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  standalone: true,
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss'],
  imports: [CommonModule, DisplayComponent]
})
export class ParentComponent {
  expression: string = '';
  result: string = '';
  darkMode: boolean = false;  // Toggle for dark mode styling

  // Function to update the expression (event binding)
  updateExpression(value: string) {
    this.expression += value;  // Append the value to the current expression
  }

  // Function to calculate the result safely
  calculateResult() {
    try {
      // Using Function constructor instead of eval() to safely calculate the expression
      this.result = new Function(`return ${this.expression}`)();
    } catch (error) {
      this.result = 'Error';  // Display 'Error' if the expression is invalid
    }
  }

  // Function to clear the expression and result
  clearExpression() {
    this.expression = '';
    this.result = '';
  }

  // Function to toggle between light and dark mode styles
  toggleStyle() {
    this.darkMode = !this.darkMode;  // Toggle the darkMode variable
  }
}
