import { Component } from '@angular/core';
import { ParentComponent } from './parent/parent.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  imports: [CommonModule, ParentComponent]
})
export class AppComponent {}





// @Input Decorator
// The @Input decorator allows the parent component to pass data to the child component via property binding.

// @Component({
//   selector: 'app-root',
//   template: `<app-child [parentData]="data"></app-child>`,
// })
// export class AppComponent {
//   data = 'Hello from Parent';
// }

// // Child component (child.component.ts)
// @Component({
//   selector: 'app-child',
//   template: `<p>Received from parent: {{ parentData }}</p>`,
// })
// export class ChildComponent {
//   @Input() parentData: string; // Decorated with @Input to receive data from parent
// }


// @ViewChild Decorator
// The @ViewChild decorator allows a parent component to access and interact with a child component’s properties and methods directly.


// @Component({
//   selector: 'app-root',
//   template: `<app-child></app-child> <button (click)="changeMessage()">Change Message</button>`,
// })
// export class AppComponent {
//   @ViewChild(ChildComponent) childComponent: ChildComponent;

//   changeMessage() {
//     this.childComponent.childMessage = 'Message changed by Parent';
//   }
// }

// // Child component (child.component.ts)
// @Component({
//   selector: 'app-child',
//   template: `<p>{{ childMessage }}</p>`,
// })
// export class ChildComponent {
//   childMessage = 'Hello from Child';
// }
