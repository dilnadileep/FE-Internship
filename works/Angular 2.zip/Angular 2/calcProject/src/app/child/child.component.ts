import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-child',
  standalone: true,
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss'],
  imports: [CommonModule]
})
export class DisplayComponent {
  @Input() expression: string = '';     // Input property for the expression from the parent
  @Input() result: string = '';         // Input property for the result from the parent
  @Input() darkMode: boolean = false;   // Input property for dark mode toggle
}

