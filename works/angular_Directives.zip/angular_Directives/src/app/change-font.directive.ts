import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appChangeFont]',
  standalone: true  
})
export class ChangeFontDirective {
  @Input() appChangeFont: boolean = true; // Input to enable or disable the directive
  @Input() fontColor: string = 'red'; // Default font color
  @Input() fontWeight: string = 'normal'; // Default font weight
  @Input() changeOn: 'hover' | 'click' = 'hover'; // Event type for triggering style change

  

  constructor(private el: ElementRef, private renderer: Renderer2) {}

  private applyStyle() {
    if (this.appChangeFont) {
      this.renderer.setStyle(this.el.nativeElement, 'color', this.fontColor);
      this.renderer.setStyle(this.el.nativeElement, 'font-weight', this.fontWeight);
    }
  }

  private resetStyle() {
    if (this.appChangeFont) {
      this.renderer.removeStyle(this.el.nativeElement, 'color');
      this.renderer.removeStyle(this.el.nativeElement, 'font-weight');
    }
  }

  @HostListener('mouseenter') onMouseEnter() {
    if (this.changeOn === 'hover') this.applyStyle();
  }

  @HostListener('mouseleave') onMouseLeave() {
    if (this.changeOn === 'hover') this.resetStyle();
  }

  @HostListener('click') onClick() {
    if (this.changeOn === 'click') this.applyStyle();
  }
}
