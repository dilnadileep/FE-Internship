import { ChangeFontDirective } from './change-font.directive';

describe('ChangeFontDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeFontDirective();
    expect(directive).toBeTruthy();
  });
});
